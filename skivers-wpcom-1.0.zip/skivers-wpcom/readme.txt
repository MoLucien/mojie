=== Skivers ===
Contributors: Automattic
Requires at least: 5.8
Tested up to: 5.8
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Skivers is a minimalist theme, designed for single-page websites. Its single post and page layouts have no header, navigation menus, or widgets by default, so the page you design in the WordPress editor is the same page you’ll see on the front end.

== Changelog ==

= 10 January 2022 =
* Kerr, Byrne, Skivers, Payton: Update parent template in style.css

= 6 December 2021 =
* Update headstart annotation.
* Add POT file.
* Add headstart annotations.
* Update footer template.
* Fix path to parent theme.
* Update theme color palette.
* Initial commit.

== Copyright ==

Skivers WordPress Theme, (C) 2021 Automattic
Skivers is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Skivers uses the following third-party resources:

Concert Singer Free Stock Image by Austin Neill
https://stocksnap.io/photo/concert-singer-F66MXRQS1K
Included in theme screenshot and demo site.
